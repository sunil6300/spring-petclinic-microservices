#!/bin/bash

VOLUME_HOME="/var/lib/mysql"
CONF_FILE="/etc/mysql/conf.d/my.cnf"
LOG="/var/log/mysql/error.log"

chmod 644 ${CONF_FILE}
chmod 644 /etc/mysql/conf.d/mysqld_charset.cnf

StartMySQL ()
{
    # /usr/bin/mysqld_safe --skip-grant-tables > /dev/null 2>&1 &
    /usr/bin/mysqld_safe  > /dev/null 2>&1 &

    # Time out in 1 minute
    LOOP_LIMIT=13
    for (( i=0 ; ; i++ )); do
        if [ ${i} -eq ${LOOP_LIMIT} ]; then
            echo "Time out. Error log is shown as below:"
            tail -n 100 ${LOG}
            exit 1
        fi
        echo "=> Waiting for confirmation of MySQL service startup, trying ${i}/${LOOP_LIMIT} ..."
        sleep 5
        mysql -uroot -e "status" > /dev/null 2>&1 && break
    done
}

StartMySQLWithPwd()
{
    # /usr/bin/mysqld_safe --skip-grant-tables > /dev/null 2>&1 &
    /usr/bin/mysqld_safe > /dev/null 2>&1 &

    # Time out in 1 minute
    LOOP_LIMIT=13
    for (( i=0 ; ; i++ )); do
        if [ ${i} -eq ${LOOP_LIMIT} ]; then
            echo "Time out. Error log is shown as below:"
            tail -n 100 ${LOG}
            exit 1
        fi
        echo "=> Waiting for confirmation of MySQL service startup, trying ${i}/${LOOP_LIMIT} ..."
        sleep 5
        mysql -uroot -proot -e "status" > /dev/null 2>&1 && break
    done
}


CreateMySQLUser()
{
	StartMySQL
	PASS="test123"
	mysql -uroot -e "CREATE USER '${MYSQL_USER}'@'%' IDENTIFIED BY '$PASS'"
	mysql -uroot -e "GRANT ALL PRIVILEGES ON *.* TO '${MYSQL_USER}'@'%' WITH GRANT OPTION"

	mysql -uroot -e "GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' IDENTIFIED BY 'root' WITH GRANT OPTION;"
	mysql -uroot -e "GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY 'root' WITH GRANT OPTION;"
	mysql -uroot -e "ALTER USER 'root'@'%' IDENTIFIED BY 'root' "
	mysql -uroot -e "ALTER USER 'root'@'localhost' IDENTIFIED BY 'root' "
	mysql -uroot -e "FLUSH PRIVILEGES;"

	mysqladmin -uroot shutdown
}

ImportSql()
{
       StartMySQLWithPwd
       if [ -d "/var/lib/mysql/petclinic" ]; then 
          echo 'petclinic already present, skipping creation'
       else 
        echo 'petclinic cration prepared ................'
       	mysql -uroot -proot < "/schema.sql"
       	mysql -uroot -proot < "/data.sql"
       fi 
   mysqladmin -uroot -proot shutdown
}


if [[ ! -d $VOLUME_HOME/mysql ]]; then
    if [ ! -f /usr/share/mysql/my-default.cnf ] ; then
        cp /etc/mysql/my.cnf /usr/share/mysql/my-default.cnf
    fi 
    mysql_install_db > /dev/null 2>&1
    echo "=> Creating admin user ..."
    CreateMySQLUser
 else
    echo "volume exist"
fi
ImportSql

# exec mysqld_safe --skip-grant-tables
exec mysqld_safe